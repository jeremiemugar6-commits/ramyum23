/**
 * Shared CSV export utility.
 */
export function exportToCSV(rows, columns, fileName = 'export') {
    if (!rows || !rows.length) {
        console.warn('exportToCSV: no rows');
        return;
    }
    const escape = (val) => {
        const s = val == null ? '' : String(val);
        if (s.includes(',') || s.includes('"') || s.includes('\n')) {
            return `"${s.replace(/"/g, '""')}"`;
        }
        return s;
    };
    const header = columns.map(c => escape(c.header || c.label || c.key)).join(',');
    const body = rows.map(row =>
        columns.map(c => {
            let v = typeof c.value === 'function' ? c.value(row) : row[c.key];
            if (v != null && typeof v === 'object') v = JSON.stringify(v);
            // strip simple HTML tags for export
            if (typeof v === 'string') v = v.replace(/<[^>]+>/g, '').trim();
            return escape(v);
        }).join(',')
    ).join('\n');

    const blob = new Blob([header + '\n' + body], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${fileName}_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
}
