<?php
/**
 * Batch / lot traceability.
 * GET ?batch=BT202608019  → timeline of product, movements, POs, PORs related to batch.
 */
require_once __DIR__ . '/../includes/auth.php';
require_login_api();

$batch = trim($_GET['batch'] ?? '');
if ($batch === '') {
    json_error('Query parameter "batch" is required.', 400);
}

$db = getDB();
$batchLower = mb_strtolower($batch);
$result = [
    'batch' => $batch,
    'products' => [],
    'movements' => [],
    'timeline' => [],
];

// Products matching batch
try {
    $stmt = $db->query('SELECT id, data FROM products');
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $p = json_decode($row['data'], true) ?: [];
        $bn = $p['batchNumber'] ?? $p['batch_number'] ?? '';
        if ($bn !== '' && mb_strtolower($bn) === $batchLower) {
            $result['products'][] = [
                'id' => $p['id'] ?? $row['id'],
                'name' => $p['name'] ?? '',
                'sku' => $p['sku'] ?? '',
                'stock' => $p['stock'] ?? 0,
                'batchNumber' => $bn,
                'manufacturingDate' => $p['manufacturingDate'] ?? $p['manufacturing_date'] ?? null,
                'expirationDate' => $p['expirationDate'] ?? null,
                'location' => $p['location'] ?? $p['locationName'] ?? null,
            ];
        }
    }
} catch (Throwable $e) { /* continue */ }

// Inventory movements mentioning batch
try {
    $stmt = $db->query('SELECT id, data, created_at FROM inventory_movements ORDER BY created_at DESC LIMIT 500');
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $d = json_decode($row['data'], true) ?: [];
        $bn = $d['batchNumber'] ?? $d['batch_number'] ?? '';
        $notes = mb_strtolower(($d['notes'] ?? '') . ' ' . ($d['reason'] ?? '') . ' ' . json_encode($d));
        $match = ($bn !== '' && mb_strtolower($bn) === $batchLower) || str_contains($notes, $batchLower);
        if ($match) {
            $entry = [
                'id' => $row['id'],
                'type' => $d['type'] ?? 'Movement',
                'productName' => $d['productName'] ?? '',
                'quantity' => $d['quantity'] ?? $d['change'] ?? null,
                'referenceType' => $d['referenceType'] ?? null,
                'referenceId' => $d['referenceId'] ?? null,
                'referencePO' => $d['referencePO'] ?? null,
                'user' => $d['user'] ?? null,
                'reason' => $d['reason'] ?? null,
                'notes' => $d['notes'] ?? null,
                'created_at' => $row['created_at'],
            ];
            $result['movements'][] = $entry;
            $result['timeline'][] = array_merge($entry, ['source' => 'movement']);
        }
    }
} catch (Throwable $e) { /* continue */ }

// Purchase orders / receivings that may reference batch in items (best-effort)
foreach (['purchase_orders', 'receivings'] as $collection) {
    try {
        $stmt = $db->query("SELECT id, data, created_at FROM `$collection` ORDER BY created_at DESC LIMIT 200");
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $d = json_decode($row['data'], true) ?: [];
            $blob = mb_strtolower(json_encode($d));
            if (str_contains($blob, $batchLower)) {
                $result['timeline'][] = [
                    'source' => $collection,
                    'id' => $row['id'],
                    'type' => $collection === 'purchase_orders' ? 'Purchase Order' : 'Receiving',
                    'referenceId' => $d['poNumber'] ?? $d['receivingNumber'] ?? $row['id'],
                    'status' => $d['status'] ?? null,
                    'supplier' => $d['supplier'] ?? $d['supplierName'] ?? null,
                    'created_at' => $row['created_at'] ?? $d['createdAt'] ?? null,
                ];
            }
        }
    } catch (Throwable $e) { /* table may not exist */ }
}

usort($result['timeline'], function ($a, $b) {
    return strcmp($b['created_at'] ?? '', $a['created_at'] ?? '');
});

json_response(['success' => true, 'data' => $result]);
