/**
 * Batch / Lot Traceability
 */
import { toast } from '../../assets/js/components/toast.js';
import { exportToCSV } from '../../assets/js/utils/export-csv.js';

export async function renderBatchTrace() {
    const container = document.getElementById('appContent');
    container.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:26px; flex-wrap:wrap; gap:16px; background:var(--bg-card); padding:22px 26px; border-radius:12px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm);">
            <div>
                <h1 class="page-title">Batch Traceability</h1>
                <p class="page-subtitle">Trace a batch/lot from product → movements → PO / receiving history.</p>
            </div>
        </div>

        <div class="card" style="padding:20px; margin-bottom:20px;">
            <div style="display:flex; gap:12px; flex-wrap:wrap; align-items:end;">
                <div style="flex:1; min-width:220px;">
                    <label style="display:block; font-weight:600; font-size:0.85rem; margin-bottom:6px;">Batch / Lot Number</label>
                    <input type="text" id="btBatch" class="form-input" placeholder="e.g. BT202608019" style="width:100%;">
                </div>
                <button id="btSearchBtn" class="btn btn-primary" style="background:var(--primary-red); color:#fff; border:none; padding:10px 20px; border-radius:8px; font-weight:600; cursor:pointer;">Trace Batch</button>
                <button id="btExportBtn" class="btn btn-secondary" style="display:none;">Export Timeline</button>
            </div>
        </div>

        <div id="btResults"></div>
    `;

    let lastData = null;

    const runSearch = async () => {
        const batch = document.getElementById('btBatch').value.trim();
        if (!batch) {
            toast.show('Enter a batch number', 'error');
            return;
        }
        const results = document.getElementById('btResults');
        results.innerHTML = `<div style="padding:40px; text-align:center; color:var(--text-muted);">Searching...</div>`;

        try {
            const res = await fetch(`api/batch-trace.php?batch=${encodeURIComponent(batch)}`);
            const json = await res.json();
            if (!json.success) throw new Error(json.error || 'Failed');
            lastData = json.data;
            document.getElementById('btExportBtn').style.display = 'inline-block';
            renderResults(json.data);
        } catch (e) {
            results.innerHTML = `<div class="card" style="padding:40px; text-align:center; color:var(--text-secondary);">${e.message}</div>`;
        }
    };

    document.getElementById('btSearchBtn')?.addEventListener('click', runSearch);
    document.getElementById('btBatch')?.addEventListener('keydown', e => { if (e.key === 'Enter') runSearch(); });
    document.getElementById('btExportBtn')?.addEventListener('click', () => {
        if (!lastData?.timeline?.length) return;
        exportToCSV(lastData.timeline, [
            { key: 'created_at', header: 'Date' },
            { key: 'source', header: 'Source' },
            { key: 'type', header: 'Type' },
            { key: 'productName', header: 'Product' },
            { key: 'quantity', header: 'Qty' },
            { key: 'referenceId', header: 'Reference' },
            { key: 'user', header: 'User' },
            { key: 'notes', header: 'Notes' },
        ], `batch_trace_${lastData.batch}`);
        toast.show('Timeline exported', 'success');
    });
}

function renderResults(data) {
    const el = document.getElementById('btResults');
    const products = data.products || [];
    const timeline = data.timeline || [];

    el.innerHTML = `
        <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:16px; margin-bottom:20px;">
            <div class="card" style="padding:18px;">
                <div style="font-size:0.8rem; color:var(--text-secondary); font-weight:600;">BATCH</div>
                <div style="font-size:1.25rem; font-weight:700; margin-top:4px;">${esc(data.batch)}</div>
            </div>
            <div class="card" style="padding:18px;">
                <div style="font-size:0.8rem; color:var(--text-secondary); font-weight:600;">PRODUCTS</div>
                <div style="font-size:1.25rem; font-weight:700; margin-top:4px;">${products.length}</div>
            </div>
            <div class="card" style="padding:18px;">
                <div style="font-size:0.8rem; color:var(--text-secondary); font-weight:600;">TIMELINE EVENTS</div>
                <div style="font-size:1.25rem; font-weight:700; margin-top:4px;">${timeline.length}</div>
            </div>
        </div>

        ${products.length ? `
        <div class="card" style="padding:20px; margin-bottom:20px;">
            <h3 style="margin:0 0 14px; font-size:1rem;">Matching Products</h3>
            <div style="overflow-x:auto;">
                <table style="width:100%; border-collapse:collapse; font-size:0.875rem;">
                    <thead><tr style="background:var(--bg-gray);">
                        <th style="padding:10px; text-align:left;">Product</th>
                        <th style="padding:10px; text-align:left;">SKU</th>
                        <th style="padding:10px; text-align:right;">Stock</th>
                        <th style="padding:10px; text-align:left;">Start (Mfg)</th>
                        <th style="padding:10px; text-align:left;">Expiration</th>
                    </tr></thead>
                    <tbody>
                        ${products.map(p => `
                            <tr style="border-bottom:1px solid var(--border-color);">
                                <td style="padding:10px; font-weight:600;">${esc(p.name)}</td>
                                <td style="padding:10px;">${esc(p.sku)}</td>
                                <td style="padding:10px; text-align:right;">${p.stock}</td>
                                <td style="padding:10px;">${esc(p.manufacturingDate || '—')}</td>
                                <td style="padding:10px;">${esc(p.expirationDate || '—')}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        </div>` : `<div class="card" style="padding:24px; margin-bottom:20px; color:var(--text-secondary);">No products found with this batch number.</div>`}

        <div class="card" style="padding:20px;">
            <h3 style="margin:0 0 14px; font-size:1rem;">Trace Timeline</h3>
            ${timeline.length === 0 ? `<p style="color:var(--text-muted);">No related movements or documents found.</p>` : `
            <div style="display:flex; flex-direction:column; gap:0;">
                ${timeline.map(t => `
                    <div style="display:flex; gap:14px; padding:14px 0; border-bottom:1px solid var(--border-color);">
                        <div style="width:8px; border-radius:4px; background:${t.source === 'movement' ? '#10B981' : '#3B82F6'}; flex-shrink:0;"></div>
                        <div style="flex:1;">
                            <div style="font-weight:600; color:var(--text-primary);">${esc(t.type || t.source)} ${t.productName ? '· ' + esc(t.productName) : ''}</div>
                            <div style="font-size:0.85rem; color:var(--text-secondary); margin-top:2px;">
                                ${t.quantity != null ? `Qty: ${t.quantity} · ` : ''}
                                ${t.referenceId ? `Ref: ${esc(t.referenceId)} · ` : ''}
                                ${t.user ? `User: ${esc(t.user)} · ` : ''}
                                ${t.created_at ? new Date(t.created_at).toLocaleString() : ''}
                            </div>
                            ${t.notes ? `<div style="font-size:0.8rem; color:var(--text-muted); margin-top:2px;">${esc(t.notes)}</div>` : ''}
                        </div>
                    </div>
                `).join('')}
            </div>`}
        </div>
    `;
}

function esc(s) {
    if (s == null) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
